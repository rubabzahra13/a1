$(document).ready(function () {
  // Sample data for job listings (you can replace this with your data)
  const jobListings = [
    {
      title: "Senior Frontend Developer",
      role: "frontend",
      level: "senior",
      languages: ["HTML", "CSS", "JavaScript"],
      tools: [],
      badges: ["New!", "Featured"],
      age: "1d ago",
      type: "Full Time",
      location: "USA only",
      imageUrl: "images/photosnap.svg",
    },
    {
      title: "Fullstack Developer",
      role: "fullstack",
      level: "midweight",
      languages: ["Python"],
      tools: ["React"],
      badges: ["New!", "Featured"],
      age: "1d ago",
      type: "Part Time",
      location: "Remote",
      imageUrl: "images/manage.svg",
    },
    {
      title: "Junior Frontend Developer",
      role: "frontend",
      level: "junior",
      languages: ["JavaScript"],
      tools: ["React", "Sass"],
      badges: ["New!"],
      age: "2d ago",
      type: "Part Time",
      location: "USA only",
      imageUrl: "images/account.svg",
    },
    {
      title: "Junior Frontend Developer",
      role: "frontend",
      level: "junior",
      languages: ["CSS", "JavaScript"],
      tools: [],
      badges: [],
      age: "5d ago",
      type: "Contract",
      location: "USA only",
      imageUrl: "images/myhome.svg",
    },
    {
      title: "Software Engineer",
      role: "fullstack",
      level: "midweight",
      languages: ["JavaScript", "Ruby"],
      tools: ["Sass"],
      badges: [],
      age: "1w ago",
      type: "Full Time",
      location: "Worldwide",
      imageUrl: "images/loop-studios.svg",
    },
    {
      title: "Junior Backend Developer",
      role: "backend",
      level: "junior",
      languages: ["Ruby"],
      tools: ["RoR"],
      badges: [],
      age: "2w ago",
      type: "Full Time",
      location: "UK only",
      imageUrl: "images/faceit.svg",
    },
    {
      title: "Junior Developer",
      role: "frontend",
      level: "junior",
      languages: ["HTML", "JavaScript"],
      tools: ["Sass"],
      badges: [],
      age: "2w ago",
      type: "Full Time",
      location: "Worldwide",
      imageUrl: "images/shortly.svg",
    },
    {
      title: "Junior Frontend Developer",
      role: "frontend",
      level: "junior",
      languages: ["JavaScript"],
      tools: ["Vue", "Sass"],
      badges: [],
      age: "2w ago",
      type: "Full Time",
      location: "USA only",
      imageUrl: "images/insure.svg",
    },
    {
      title: "Full Stack Engineer",
      role: "fullstack",
      level: "midweight",
      languages: ["JavaScript", "Python"],
      tools: ["Django"],
      badges: [],
      age: "3w ago",
      type: "Full Time",
      location: "Worldwide",
      imageUrl: "images/eyecam-co.svg",
    },
    {
      title: "Front-end Dev",
      role: "frontend",
      level: "junior",
      languages: ["JavaScript"],
      tools: ["React", "Sass"],
      badges: [],
      age: "1mo ago",
      type: "Part Time",
      location: "Worldwide",
      imageUrl: "images/the-air-filter-company.svg",
    },
  ];

  function displayJobListings(listings) {
    const listingsContainer = $(".job-listings");
    listingsContainer.empty();

    listings.forEach((job) => {
      const jobLanguages = job.languages.join(", ");
      const jobTools = job.tools ? job.tools.join(", ") : "";
      const jobBadges = job.badges
        .map((badge) => `<div class="job-badge">${badge}</div>`)
        .join(" ");

      const companyName = job.imageUrl.split("/").pop().split(".")[0];

      const listingHTML = `
      <div class="job-listing" data-role="${job.role}" data-level="${job.level}" data-languages="${jobLanguages}" data-tools="${jobTools}">
        <div class="profile-image">
          <img src="${job.imageUrl}" alt="${job.title}">
        </div>
        <div class="job-header">
          <div class="topContent">
            <div class="company-name">${companyName}</div>
            <div>${jobBadges}</div>
          </div>
          <div class="titleButtonContainer">
            <div class="job-title">${job.title}</div>
            
          </div>
          <div class="job-details">
            <div class="job-age">${job.age}</div>
            <div class="job-type">${job.type}</div>
            <div class="job-location">${job.location}</div>
          </div>
        </div>
        <div class="jobTags"></div> <!-- Added jobTags div -->
        <button class="delete-job-button">x</button>
      </div>
    `;

      listingsContainer.append(listingHTML);

      // Add tags to the jobTags div
      const jobTagsContainer = listingsContainer.find(".jobTags").last();

      // Add tags based on job properties
      const tags = [
        { type: "Role", value: job.role },
        ...job.languages.map((language) => ({
          type: "Language",
          value: language,
        })),
        ...job.tools.map((tool) => ({ type: "Tool", value: tool })),
        { type: "Level", value: job.level },
      ];

      tags.forEach((tag) => {
        jobTagsContainer.append(
          `<botton class="job-tag"> ${tag.value}</botton>`
        );
      });
    });
  }

  // Initial display of job listings
  displayJobListings(jobListings);
  $(document).on("click", ".delete-job-button", function () {
    const jobListing = $(this).closest(".job-listing");
    const jobIndex = jobListing.index();

    // Remove the job from the jobListings array
    jobListings.splice(jobIndex, 1);

    // Update the displayed job listings
    displayJobListings(jobListings);
  });
  // Filter job listings when filter options are clicked
  $(".filter-option").click(function () {
    const filterType = $(this).data("filter");
    const filterValue = $(this).data("value");

    const filteredListings = jobListings.filter((job) => {
      if (filterType === "role" || filterType === "level") {
        return job[filterType] === filterValue;
      } else if (filterType === "languages" || filterType === "tools") {
        const filterArray = filterValue.split(", ");
        return filterArray.some((value) => job[filterType].includes(value));
      }
    });

    displayJobListings(filteredListings);
  });
  // Add a click event listener to delete filters
  $(document).on("click", ".delete-filter-button", function () {
    const filterOption = $(this).closest(".filter-option");
    const filterType = filterOption.data("filter");
    const filterValue = filterOption.data("value");

    // Remove the filter option from the filter options container
    filterOption.remove();

    // Determine the currently selected filters
    const selectedFilters = $(".filter-option")
      .map(function () {
        return {
          type: $(this).data("filter"),
          value: $(this).data("value"),
        };
      })
      .get();

    // Filter the job listings based on the selected filters
    const filteredListings = jobListings.filter((job) => {
      return selectedFilters.every((filter) => {
        const filterType = filter.type;
        const filterValue = filter.value;

        if (filterType === "role" || filterType === "level") {
          return job[filterType] === filterValue;
        } else if (filterType === "languages" || filterType === "tools") {
          const filterArray = filterValue.split(", ");
          return filterArray.some((value) => job[filterType].includes(value));
        }
        return true; // Return true for other types (not affected by this filter)
      });
    });

    // Update the displayed job listings without the removed filter
    displayJobListings(filteredListings);
  });

  // Handle job details popups (you can customize this further)
  $(".job-listing").click(function () {
    const jobTitle = $(this).find(".job-title").text();
    const jobDetails = $(this).find(".job-details").html();

    // You can display the job details in a popup/modal here
    // For example, you can create a popup div and display job details inside it
    const popupHTML = `
      <div class="job-popup">
        <h2>${jobTitle}</h2>
        ${jobDetails}
        <button class="close-popup">Close</button>
      </div>
    `;

    $("body").append(popupHTML);

    // Close the popup when the close button is clicked
    $(".close-popup").click(function () {
      $(".job-popup").remove();
    });
  });

  // Add a click event listener to the "+" button to show the Add New Job popup
  $(".add-job-button button").click(function () {
    const popupHTML = `
      <div class="job-popup">
        <h2>Add New Job</h2>
        <input type="text" id="title" name="title" placeholder="Job Title">
        <input type="text" id="description" name="description" placeholder="Job Description">
        <button id="addJob" type="submit">Add Job</button>
        <button class="close-popup">Close</button>
      </div>
    `;

    $("body").append(popupHTML);

    // Close the popup when the close button is clicked
    $(".close-popup").click(function () {
      $(".job-popup").remove();
    });

    // Handle job addition when the "Add Job" button in the popup is clicked
    $("#addJob").click(function () {
      const title = $("#title").val();
      const description = $("#description").val();

      // Check if both title and description are provided
      if (title && description) {
        // Create a new job listing with the entered data
        const newJob = {
          title: title,
          role: "custom", // Replace with the appropriate role value
          level: "custom", // Replace with the appropriate level value
          languages: [], // Replace with the appropriate languages value
          tools: [], // Replace with the appropriate tools value
          badges: [], // Replace with the appropriate badges value
          age: "New!",
          type: "Full Time",
          location: "Worldwide",
        };

        jobListings.push(newJob);

        // Update the displayed job listings
        displayJobListings(jobListings);

        // Close the popup
        $(".job-popup").remove();
      } else {
        // Display an error message if either title or description is missing
        alert("Please provide both a job title and description.");
      }

      // Prevent the default form submission behavior
      return false;
    });
  });
});